#from .models import MLP, CNN, BinaryConnect, BinaryNet
from .models import *
from .models_STE import *
from .simple_models import *
